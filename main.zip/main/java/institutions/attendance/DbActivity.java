package institutions.attendance;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import java.io.InputStream;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Iterator;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class DbActivity extends AppCompatActivity {

    private static final int FILE_SELECT_CODE = 302;
    TeacherDatabase td;
    Button b, b1,b2,close;
    String name;
    TextView tv;
    Dialog mydialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_db);
        td = new TeacherDatabase(this);
        td.open();
        tv = (TextView) findViewById(R.id.textView);
        b1 = (Button) findViewById(R.id.button2);
        b = (Button) findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button5);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydialog=new Dialog(DbActivity.this);
                mydialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                mydialog.setContentView(R.layout.popup);
                mydialog.setTitle("File format");
                close=(Button)mydialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mydialog.cancel();
                    }
                });
                mydialog.show();
            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                Uri u = Uri.parse(Environment.getExternalStorageDirectory().getPath().toString());
                intent.setDataAndType(u, "*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                //Toast.makeText(getApplicationContext(),"Am outside Start Activity",Toast.LENGTH_LONG).show();
                try {
                    startActivityForResult(
                            Intent.createChooser(intent, "Select a File to Upload"), FILE_SELECT_CODE);
                    //Toast.makeText(getApplicationContext(),"Am inside Start Activity",Toast.LENGTH_LONG).show();
                } catch (android.content.ActivityNotFoundException ex) {
                    // Potentially direct the user to the Market with a Dialog
                    Toast.makeText(getApplicationContext(), "Please install a File Manager.",
                            Toast.LENGTH_SHORT).show();
                }

                //InputStream is1=new FileInputStream("C:/Test.xls");


                finally {
                    Toast.makeText(getApplicationContext(), "Details saved successfully", Toast.LENGTH_LONG).show();
                }
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name = td.searchNames();
                tv.setText(name);
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case FILE_SELECT_CODE:
                if (resultCode == RESULT_OK) {
                    try {
                        XSSFWorkbook wb = new XSSFWorkbook(getContentResolver().openInputStream(data.getData()));
                        TeacherDatabase td = new TeacherDatabase(this);
                        td.open();
                        XSSFSheet sheet = wb.getSheetAt(0);
                        XSSFRow row;
                        XSSFCell cell;

                        Iterator rows = sheet.rowIterator();
                        String s[] = new String[10];
                        while (rows.hasNext()) {
                            int j = 0;
                            row = (XSSFRow) rows.next();
                            Iterator cells = row.cellIterator();
                            while (cells.hasNext()) {
                                cell = (XSSFCell) cells.next();

                                if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
                                    s[j++] = cell.getStringCellValue();
                                }
                                else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
                                    s[j++] = NumberToTextConverter.toText(cell.getNumericCellValue());
                                }
                                else
                                {

                                }
                            }
                            //Toast.makeText(getApplicationContext(),s[0]+" "+s[1],Toast.LENGTH_LONG).show();
                            td.insertEntry(s[0],s[1]);

                            //U Can Handel Boolean, Formula, Errors
                        }
                    }
                    catch (Exception e) {

                    }


                }

        }
    }
}

