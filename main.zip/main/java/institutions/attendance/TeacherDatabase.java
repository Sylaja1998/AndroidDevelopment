package institutions.attendance;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by User on 3/18/2018.
 */

public class TeacherDatabase {
    private static final String DB_Name="Mydb.db";
    private static final int version=1;
    private static final String crea="create table parentdb(Rollno text not null,Phnno text not null);";
    private SQLiteDatabase db;
    private final Context c;
    private MyDBHelper dbh;
    public TeacherDatabase(Context co){
        c=co;
        dbh=new MyDBHelper(c,DB_Name,null,version);
    }
    public TeacherDatabase open() throws SQLException {
        db=dbh.getWritableDatabase();
        return this;
    }
    public void close(){
        db.close();
    }
    public void insertEntry(String na,String phn){
        ContentValues value=new ContentValues();
        value.put("Rollno", na);
        value.put("Phnno",phn);
        db.insert("parentdb", null, value);
    }

    public String searchNames(){
        String st="";
        Cursor c=db.query("parentdb", null,null,null , null, null, null);
        if(c.moveToFirst())
            do
            { st =st+" "+c.getString(1);
            }while(c.moveToNext());
        return st;
    }
    public String searchNum(String s){
        String st="";
        Cursor c=db.query("parentdb", null,"Rollno=?",new String[]{s} , null, null, null);
        if(c.moveToFirst())
            do
            { st =c.getString(1);
            }while(c.moveToNext());
        return st;
    }
    private static class MyDBHelper extends SQLiteOpenHelper {
        public MyDBHelper(Context con, String name, SQLiteDatabase.CursorFactory cf, int ver){
            super(con,name,cf,ver);
        }
        public void onCreate(SQLiteDatabase sd){
            sd.execSQL(crea);
        }
        public void onUpgrade(SQLiteDatabase sd,int ov,int nv){

        }
    }
}
