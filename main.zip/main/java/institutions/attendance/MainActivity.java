package institutions.attendance;

import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.ArrayList;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity {

    private static final int FILE_SELECT_CODE=302;
    Button b,b1,b2,close;
    Dialog mydialog;
    String x1="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*String dir = "/storage/emulated/0/Download/";
        File f = new File(dir);
        String[] files = f.list();
        for(int i=0; i<files.length; i++){
            x1=x1+files[i];
        }*/
        //x1="Working directory="+System.getProperty("user.dir");
        b=(Button)findViewById(R.id.button3);
        b1=(Button)findViewById(R.id.button4);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),DbActivity.class);
                startActivity(i);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                Uri u=Uri.parse(Environment.getExternalStorageDirectory().getPath().toString());
                intent.setDataAndType(u,"*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                //Toast.makeText(getApplicationContext(),"Am outside Start Activity",Toast.LENGTH_LONG).show();
                try {
                    startActivityForResult(
                            Intent.createChooser(intent, "Select a File to Upload"),FILE_SELECT_CODE);
                    //Toast.makeText(getApplicationContext(),"Am inside Start Activity",Toast.LENGTH_LONG).show();
                } catch (android.content.ActivityNotFoundException ex) {
                    // Potentially direct the user to the Market with a Dialog
                    Toast.makeText(getApplicationContext(), "Please install a File Manager.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
        b2=(Button)findViewById(R.id.button5);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydialog=new Dialog(MainActivity.this);
                mydialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                mydialog.setContentView(R.layout.popupp);
                mydialog.setTitle("File format");
                close=(Button)mydialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mydialog.cancel();
                    }
                });
                mydialog.show();
            }
        });

    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        switch (requestCode) {
            case FILE_SELECT_CODE:
                if (resultCode == RESULT_OK) {
                    try {

                        XSSFWorkbook wb = new XSSFWorkbook(getContentResolver().openInputStream(data.getData()));
                        TeacherDatabase td=new TeacherDatabase(this);
                        td.open();
                        XSSFSheet sheet = wb.getSheetAt(0);
                        XSSFRow row;
                        XSSFCell cell;

                        Iterator rows = sheet.rowIterator();
                        String s[]=new String[10];
                        String num;
                        int a[]=new int[10];
                        while (rows.hasNext()) {
                            x1 = "";
                            int i=0;
                            int j=0;
                            int k;
                            row = (XSSFRow) rows.next();
                            Iterator cells = row.cellIterator();
                            while (cells.hasNext()) {
                                cell = (XSSFCell) cells.next();
                                int temp=0;

                                if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
                                    s[j++]=cell.getStringCellValue();
                                } else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
                                    temp=(int)cell.getNumericCellValue();
                                    if(temp>=0)
                                        a[i++]=temp;

                                }
                                else {

                                }

                                //U Can Handel Boolean, Formula, Errors
                            }
                            num =td.searchNum(s[0]);
                            //Toast.makeText(getApplicationContext(),num,Toast.LENGTH_LONG).show();
                            String msg="Your ward "+s[0]+" has secured Internal marks as:";
                            //Toast.makeText(getApplicationContext(),s[0],Toast.LENGTH_LONG).show();
                            for(k=0;k<i-1;k++)
                                msg=msg+a[k]+" ";
                            sendmsg(num,msg);
                            msg=s[0]+" has attendance "+a[k]+" Dec 20 to March 15,2018.Kindly contact tutor "+s[1]+",if attendance is less than 75%";
                            sendmsg(num,msg);

                        }

                    }
                    catch (Exception e) {
                        // TODO Auto-generated catch block
                    }
                }
                break;
        }

    }
    public void sendmsg(String num,String msg)
    {
        try {
            SmsManager sms = SmsManager.getDefault();
            PendingIntent sentPI;
            String SENT = "SMS_SENT";
            int id = (int) System.currentTimeMillis();
            sentPI = PendingIntent.getBroadcast(getApplicationContext(), id, new Intent(SENT), 0);
            sms.sendTextMessage(num, null, msg, sentPI, null);

        }
        catch (Exception e)
        {

        }
        finally {
            Toast.makeText(getApplicationContext(),"Message sent successfully",Toast.LENGTH_LONG).show();
        }
    }



}
